﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebSiteApp.ServiceReference2;

namespace WebSiteApp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ServiceReference2.Service1Client myClient = new ServiceReference2.Service1Client();

            //get input info
            String input = inputTextBox.Text;
            stringStatistics statistic = myClient.analyzerStr(input);

            VowelTextBox.Text = Convert.ToString(statistic.Vowel);
            UpperTextBox.Text = Convert.ToString(statistic.Uppercase);
            WordNumTextBox.Text = Convert.ToString(myClient.wordCount(input));
        }
    }
}